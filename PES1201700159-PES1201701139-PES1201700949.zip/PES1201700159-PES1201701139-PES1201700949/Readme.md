# Steps to execute

+ To Run the Bloom-Filter
	g++ Bloom_Filter_main.cpp -o BFM
	
+ To Run Input.cpp
	Dataset File required : https://raw.githubusercontent.com/rlilojr/Detecting-Malicious-URL-Machine-Learning/master/dataset.csv
	gcc Input.cpp
